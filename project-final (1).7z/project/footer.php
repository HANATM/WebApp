<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>Nos produits</h3>
         <a href="index.php">Par catégorie</a>
         <a href="index.php">Par disponibilité</a>
      </div>

      <div class="box">
         <h3>A propos</h3>
         <a href="login.php">Se connecter</a>
         <a href="register.php">S'abonner</a>
         <a href="contact.php">Nous contacter</a>
      </div>
   </div>
</section>