<header class="header">
   <div class="header-2">
      <div class="flex">
         <a href="index.php" class="logo">Bookly.</a>

         <h1>Bookly</h1>
      </div>
      <div class="contact">
         <p class="phone">Contact: 00 00 00 00</p>
      </div>
   </div>

</header>